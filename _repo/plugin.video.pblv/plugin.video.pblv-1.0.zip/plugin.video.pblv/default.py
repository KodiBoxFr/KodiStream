# -*- coding: utf-8 -*-

import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re, sys, os, urllib
import client
import kodi
import dom_parser2
import requests
import log_utils
import urlresolver
from libs import utils

base_domain  = 'https://www.mamcin.com'
base_name    = base_domain.replace('www.',''); base_name = re.findall('(?:\/\/|\.)([^.]+)\.',base_name)[0].title()

def run():
	# Get params
	params = utils.get_params()

	if params.get('mode') is None:
		Main_menu()
	elif params.get('mode') == 'episodes_list':
		url = params.get('url')
		Get_Content(url)
	elif params.get('mode') == 'play_episode':
		url = params.get('url')
		name = params.get('name')
		iconimage = params.get('iconimage')
		resolve(url, name, iconimage)

	utils.closeItemList()

def Main_menu():
	#addDir(name, url, mode, iconimage, fanart, description)
	utils.addDir('Episodes', utils.base_url, 'episodes_list', utils.art + '/episodes/icon.png', utils.fanart, '')
	xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Content(url):

	try:
		if not url: url = utils.base_url
		c = client.request(url)
		r = dom_parser2.parse_dom(c, 'div',  {'class': 'tag-episode'})
		r = [(dom_parser2.parse_dom(i, 'a', req=['href','title']), \
			dom_parser2.parse_dom(i, 'img', req='src')) \
			for i in r if i]
		r = [(i[0][0].attrs['href'], i[0][1].content, i[1][0].attrs['src']) for i in r]

		if ( not r ):
			log_utils.log('Scraping Error in %s:: Content of request: %s' % (base_name.title(),str(c)), log_utils.LOGERROR)
			kodi.notify(msg='Scraping Error: Info Added To Log File', duration=6000, sound=True)
	except Exception as e:
		log_utils.log('Fatal Error in %s:: Error: %s' % (base_name.title(),str(e)), log_utils.LOGERROR)
		kodi.notify(msg='Fatal Error', duration=4000, sound=True)
		quit()    

	dirlst = []

	for i in r:
		try:
			items = len(r)
			title = i[1].title()
			title = title.encode('utf-8')
			if 'Épisode' in title:
				name = title.replace('Plus Belle La Vie Épisode', 'Episode')
			else:
				name = title.replace('Plus Belle La Vie ÉPisode', 'Episode')
			icon = i[2]
			url = i[0]

			# utils.addDir(name, url, 'play_episode', icon, utils.fanart, '')
			utils.addDir2(name, url, 'play_episode', icon, icon, items)

		except Exception as e:
			log_utils.log('Error adding menu item %s in %s:: Error: %s' % (i[1].title(),base_name.title(),str(e)), log_utils.LOGERROR)

	# xbmc.executebuiltin('Container.SetViewMode(523)')
	utils.setView('movies', 'movie-view')

def resolve(url, name=None, iconimage=None):

	dp = xbmcgui.DialogProgress()
	dp.create(utils.AddonTitle,'Ouverture de flux...')
	dp.update(0)

	progress = int(0)

	try:
		c = client.request(url)
		r = dom_parser2.parse_dom(c, 'iframe', req=['src'])
		r = [i.attrs['src'] for i in r if urlresolver.HostedMediaFile(i.attrs['src']).valid_url()]
		url = r[0]

	except:
		kodi.idle()
		kodi.notify(msg='Error getting link for (Link Finder) %s' % name)
		kodi.idle()
		quit()

	u = urlresolver.HostedMediaFile(url).resolve()
	liz = xbmcgui.ListItem(name, iconImage = iconimage, thumbnailImage = iconimage)

	liz.setInfo(type="Video", infoLabels={"Title": name})
	liz.setProperty("IsPlayable","true")
	liz.setPath(u)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

	# xbmc.Player().play(u, liz, False)

	while not xbmc.Player().isPlaying():
		dp.update(int(progress), 'Ouverture de flux...', '')
	dp.close()

if __name__ == '__main__':
	run()

# xbmcplugin.endOfDirectory(int(sys.argv[1]))