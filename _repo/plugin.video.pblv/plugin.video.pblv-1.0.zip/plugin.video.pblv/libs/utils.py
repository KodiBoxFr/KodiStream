import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import os, sys, urllib

import log_utils

from addon.common.addon import Addon
from libs import api

# addon = xbmcaddon.Addon()
# addon_id = addon.getAddonInfo('id')
addon_id = 'plugin.video.pblv'
selfAddon = xbmcaddon.Addon(id=addon_id)

addon = Addon(addon_id, sys.argv)

ADDON = xbmcaddon.Addon()

ADDON_PATH = ADDON.getAddonInfo('path')

# AddonTitle = addon.getAddonInfo('name')
AddonTitle = ADDON.getAddonInfo('name')

# addon_path = addon.getAddonInfo('path')

# icon = addon.getAddonInfo('icon')
# fanart = addon.getAddonInfo('fanart')
# art = addon_path + '/resources/art/' 

icon = ADDON.getAddonInfo('icon')
fanart = ADDON.getAddonInfo('fanart')
art = ADDON_PATH + '/resources/art/' 

base_url = 'https://www.mamcin.com/category/non-classe/'

def get_params():
	args = sys.argv[2]

	commands = {}

	if args:
		split_commands = args[args.find('?') +1:].split('&')

		for command in split_commands:
			if len(command) > 0:
				if '=' in command:
					split_command = command.split('=')
					key = split_command[0]
					value = urllib.unquote_plus(split_command[1])
					commands[key] = value
				else:
					commands[command] = ''

	return commands

# def addDir(name, url, mode, iconimage, fanart, description):
# 	u = sys.argv[0]+'?url='+urllib.quote_plus(url)+'&mode='+str(mode)+'&name='+urllib.quote_plus(name)+'&iconimage='+urllib.quote_plus(iconimage)+'&description='+urllib.quote_plus(description)

# 	if mode == 'play_episode':
# 		serie_id = int(97371)
# 		episode_id = int(name.replace('Episode ', ''))

# 		saison = api.Saison(episode_id)
# 		episode = api.Episode(saison, episode_id)

# 		thetvdb = api.TheTVDB()
		
# 		iconimage = thetvdb.seriePoster(serie_id)
# 		description = thetvdb.getEpisode(serie_id, saison, episode)

# 	# liz = xbmcgui.ListItem(name, iconImage = 'DefaultFolder.png', thumbnailImage = iconimage)
# 	liz = xbmcgui.ListItem(label = name)
# 	liz.setArt({'poster': iconimage, 'thumb': iconimage, 'icon': 'DefaultFolder.png', 'fanart': iconimage})
# 	# liz.setInfo(type = 'Video', infoLabels = {'title': 'Plus belle la vie', 'tagline': name, 'premiered': '2005-03-04', 'plot': description})
# 	liz.setInfo('video', {'title': 'Plus belle la vie', 'tagline': name, 'plot': description})
# 	# liz.setProperty('fanart_image', iconimage)

# 	if mode == 'play_episode':
# 		liz.setProperty("IsPlayable","true")
# 		xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = False)
# 	else:
# 		xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)

def addDir(name, url, mode, iconimage, fanart, description):
	u = sys.argv[0]+'?url='+urllib.quote_plus(url)+'&mode='+str(mode)+'&name='+urllib.quote_plus(name)+'&iconimage='+urllib.quote_plus(iconimage)+'&description='+urllib.quote_plus(description)

	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)

	xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)

def addDir2(name, url, mode, iconimage, fanart, itemcount):
	serie_id = int(97371)
	episode_id = int(name.replace('Episode ', ''))

	saison = api.Saison(episode_id)
	episode = api.Episode(saison, episode_id)

	thetvdb = api.TheTVDB()

	meta = {}

	infos_serie = thetvdb.getSerie(serie_id)

	infos_episode = thetvdb.getEpisode(serie_id, saison, episode)

	meta.update(infos_serie)
	meta.update(infos_episode)

	# log_utils.log('### META: %s ###' % meta, log_utils.LOGERROR)

	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)	

	liz=xbmcgui.ListItem(name, iconImage=meta['cover_url'], thumbnailImage=meta['cover_url'])
	liz.setInfo( type="Video", infoLabels= meta )

        video_streaminfo = {'codec': 'h264', 'aspect': 1.78}
        liz.addStreamInfo('video', video_streaminfo)

        audio_streminfo = {'codec': 'aac', 'channels': 2}
        liz.addStreamInfo('audio', audio_streminfo)

	# contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
	# liz.addContextMenuItems(contextMenuItems, replaceItems=False)

	# if not meta['backdrop_url'] == '':
	# 	liz.setProperty('fanart_image', meta['backdrop_url'])
	# else:
	# 	liz.setProperty('fanart_image', fanart)

        liz.setProperty('fanart_image', fanart)

	# liz.setProperty("IsPlayable","true")
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=itemcount)

def closeItemList():
	xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True)

def setView(content, viewType):
    ''' Why recode whats allready written and works well,
    Thanks go to Eldrado for it '''
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.get_setting('auto-view') == 'true':

        print addon.get_setting(viewType)
        if addon.get_setting(viewType) == 'Info':
            VT = '504'
        elif addon.get_setting(viewType) == 'Info2':
            VT = '503'
        elif addon.get_setting(viewType) == 'Info3':
            VT = '515'
        elif addon.get_setting(viewType) == 'Fanart':
            VT = '508'
        elif addon.get_setting(viewType) == 'Poster Wrap':
            VT = '501'
        elif addon.get_setting(viewType) == 'Big List':
            VT = '51'
        elif addon.get_setting(viewType) == 'Low List':
            VT = '724'
        elif addon.get_setting(viewType) == 'List':
            VT = '50'
        elif addon.get_setting(viewType) == 'Default Menu View':
            VT = addon.get_setting('default-view1')
        elif addon.get_setting(viewType) == 'Default TV Shows View':
            VT = addon.get_setting('default-view2')
        elif addon.get_setting(viewType) == 'Default Episodes View':
            VT = addon.get_setting('default-view3')
        elif addon.get_setting(viewType) == 'Default Movies View':
            VT = addon.get_setting('default-view4')
        elif addon.get_setting(viewType) == 'Default Docs View':
            VT = addon.get_setting('default-view5')
        elif addon.get_setting(viewType) == 'Default Cartoons View':
            VT = addon.get_setting('default-view6')
        elif addon.get_setting(viewType) == 'Default Anime View':
            VT = addon.get_setting('default-view7')

        print viewType
        print VT
        
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )

    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )


