# -*- coding: utf-8 -*-

import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re, sys, os, urllib
import client
import kodi
import dom_parser2
import requests
import log_utils
import urlresolver
from libs import utils
from libs import linkfinder
from scrapers import __all__
from scrapers import *

buildDirectory = utils.buildDir

base_domain  = 'https://www.mamcin.com'
base_name    = base_domain.replace('www.',''); base_name = re.findall('(?:\/\/|\.)([^.]+)\.',base_name)[0].title()

def run():
	# Get params
	params = utils.get_params()

	if params.get('mode') is None:
		Main_menu()
	elif params.get('mode') == 'episodes_list':
		Episodes_menu()
	elif params.get('mode') == '810':
		url = params.get('url')
		name = params.get('name')
		iconimage = params.get('iconimage')
		linkfinder.find(url, name, iconimage)

	utils.closeItemList()

def Main_menu():

	art = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.pblv/resources/art/', 'main/%s.png'))

	dirlst = []

	c = []

	c += [
		 ('Derniers épisodes', None, 'episodes_list', 'episodes', None, True), \
		 ('Rechercher...', None, 'search', 'search', None, True), \
		 ('Paramètres', None, 'settings', 'settings', None, True)
		 ]

	for i in c:
		icon = art % i[3]
		fanart = utils.fanart
		dirlst.append({'name': i[0], 'url': i[1], 'mode': i[2], 'icon': icon, 'fanart': fanart, 'description': i[4], 'folder': i[5]})

	buildDirectory(dirlst, cache=False)

def Episodes_menu():
	sources = __all__ ; episodes_sources = []; base_name = []; url_name = []; menu_mode = []; art_dir = []

	for i in sources:
		base_name.append(eval(i + ".base_name"))
		menu_mode.append(eval(i + ".menu_mode"))
		url_name.append(eval(i + ".url_name"))
		art_dir.append(i.replace('_movies',''))
		episodes_sources = zip(base_name, url_name, menu_mode,art_dir)

	if episodes_sources:
		for i in episodes_sources:
			if i[3] == 'mamcin':
			 	from scrapers import mamcin
			 	mamcin.Get_Content(i[1])

if __name__ == '__main__':
	run()