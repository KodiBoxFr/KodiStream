import os, sys, xbmc, xbmcaddon
from libs import log_utils
from addon.common.addon import Addon

addon_id = 'plugin.video.pblv'
ADDON = xbmcaddon.Addon()

repo_id = 'repository.kodistream'
REPO = xbmcaddon.Addon(repo_id)

addon_path = xbmc.translatePath(os.path.join('special://home/addons', 'repository.kodistream'))
addonxml=xbmc.translatePath(os.path.join('special://home/addons', 'repository.kodistream','addon.xml'))

try:
    AddonVersion = ADDON.getAddonInfo('version')
    RepoVersion = REPO.getAddonInfo('version')

    log_utils.log('######################### PBLV ############################', log_utils.LOGNOTICE)
    log_utils.log('############## CURRENT PBLV VERSIONS REPORT ###############', log_utils.LOGNOTICE)   
    log_utils.log('############## PBLV PLUGIN VERSION: %s ###################' % str(AddonVersion), log_utils.LOGNOTICE)     
    log_utils.log('########## KODISTREAM REPOSITORY VERSION: %s #############' % str(RepoVersion), log_utils.LOGNOTICE)
    log_utils.log('###########################################################', log_utils.LOGNOTICE)
except:
    log_utils.log('######################### PBLV ############################', log_utils.LOGNOTICE)
    log_utils.log('############## CURRENT PBLV VERSIONS REPORT ###############', log_utils.LOGNOTICE)
    log_utils.log('############## ERROR GETTING PBLV VERSIONS ################', log_utils.LOGNOTICE)
    log_utils.log('###########################################################', log_utils.LOGNOTICE)

xbmc.executebuiltin('UpdateLocalAddons') 
xbmc.executebuiltin("UpdateAddonRepos")