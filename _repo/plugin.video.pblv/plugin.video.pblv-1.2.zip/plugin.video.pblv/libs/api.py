from __future__ import division
from decimal import *
import datetime
from xml.etree.ElementTree import ElementTree
import urllib, urllib2, zipfile, os

def Saison(episode_id):
    saison = episode_id/260
    saison = Decimal(saison).quantize(Decimal('.01'), rounding=ROUND_UP)
    if saison %1 == 0:
        saison = int(saison)
    else:
        saison = int(saison)+1
    return saison

def Episode(saison, episode_id):
    episode = (saison*260) - episode_id
    episode = 260 - episode
    return episode


class TheTVDB():
    def __init__(self):
	self.series = {}
	self.api_key = '115E36A2DA5E6CEE'
	self.url = 'http://www.thetvdb.com/api/' + self.api_key
	self.searchurl = 'http://www.thetvdb.com/api/'
	self.imageurl = 'http://www.thetvdb.com/banners/'

    def getSerie(self, serie_id, lang = 'fr'):
        geturl = self.url+'/series/%s/%s.xml' % (serie_id, lang)
        u = urllib2.urlopen(geturl)
        tree = ElementTree()
        tree.parse(u)
        root = tree.getroot()
        info = root.find("Series") 
        premiered = info.find('FirstAired').text
        # premiered = datetime.datetime.strptime(premiered, "%Y-%m-%d")

        infos = {}

        infos['rating'] = info.find('Rating').text
        infos['votes'] = ''
        # infos['year'] = premiered.year
        infos['year'] = premiered.split('-')[0]
        duration = info.find('Runtime').text
        duration = (int(duration))*60
        infos['duration'] = duration
        # infos['title'] = info.find('SeriesName').text
        infos['imdb_id'] = info.find('IMDB_ID').text
        infos['cover_url'] = self.imageurl + info.find('poster').text
        infos['backdrop_url'] = self.imageurl + info.find('fanart').text
        infos['studio'] = info.find('Network').text
        infos['thumb_url'] = self.imageurl + info.find('fanart').text
        infos['overlay'] = 6
        infos['mpaa'] = info.find('ContentRating').text
        infos['playcount'] = 0
        infos['trailer_url'] = ''
        infos['trailer'] = ''

        genre = info.find('Genre').text
        genre = genre[1:-1]
        genre = genre.replace('|', ' / ')
        infos['genre'] = genre

        infos['cast'] = [g for g in info.findtext("Actors").split("|") if g]

        return infos
        # infos = {'year': year, 'duration': duration, 'imdb_id': imdb_id, 'premiered': premiered}

    def getEpisode(self, serie_id, saison_id, episode_id, lang = 'fr'):
        geturl = self.url+'/series/%s/default/%s/%s/%s.xml' % (serie_id, saison_id, episode_id, lang)
        u = urllib2.urlopen(geturl)
        tree = ElementTree()
        tree.parse(u)
        root = tree.getroot()
        info = root.find('Episode')

        infos = {}

        infos['season'] = int(info.find('SeasonNumber').text)
        infos['episode'] = int(info.find('EpisodeNumber').text)
        infos['premiered'] = info.find('FirstAired').text
        infos['plot'] = info.find('Overview').text
        # infos['tagline'] = info.find('EpisodeName').text
        infos['title'] = info.find('EpisodeName').text
        infos['director'] = ''
        infos['writer'] = ''
        infos['imgs_prepacked'] = 'false'

        return infos