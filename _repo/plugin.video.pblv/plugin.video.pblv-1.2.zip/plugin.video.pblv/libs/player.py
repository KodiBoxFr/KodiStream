import xbmc, xbmcaddon, xbmcgui
import os, re, urllib, time
import kodi
import client
import log_utils
import urlresolver

import utils

def resolve_url(url, name=None, iconimage=None, pattern=None):

	kodi.busy()

	try: url,site = url.split('|SPLIT|')
	except: 
		site = 'Unknown'
		log_utils.log('Error getting site information from :: %s' % (url), log_utils.LOGERROR)

	if not name: name = 'Unknown'
	if not iconimage: iconimage = kodi.addonicon

	if 'site=' in url: url,site = url.split('site=')

	u = None
	log_utils.log('Sending %s to Url Resolver' % (url), log_utils.LOGNOTICE)

	if urlresolver.HostedMediaFile(url).valid_url(): 
		log_utils.log('%s is a valid SMU resolvable URL. Attempting to resolve.' % (url), log_utils.LOGNOTICE)
		try:
			u = urlresolver.HostedMediaFile(url).resolve()
		except Exception as e:
			log_utils.log('Error getting valid link from SMU :: %s :: %s' % (url, str(e)), log_utils.LOGERROR)
			kodi.idle()
			kodi.notify(msg='Something went wrong!  | %s' % str(e), duration=8000, sound=True)
			quit()
		log_utils.log('Link returned by Url Resolver :: %s' % (u), log_utils.LOGNOTICE)
	else:
		log_utils.log('%s is not a valid SMU resolvable link.' % (url), log_utils.LOGNOTICE)

	if u:
		kodi.idle()
		play(u,name,iconimage,url,site)
	else: 
		kodi.idle()
		log_utils.log('Failed to get any playable link for :: %s' % (url), log_utils.LOGERROR)
		kodi.notify(msg='Failed to get any playable link.', duration=7500, sound=True)
		quit()

def play(url, name, iconimage=None, ref=None, site=None):

	try:
		kodi.busy()

		if not site: 
			if 'site=' in url: url,site = url.split('site=')
			else: site = 'Unknown'
		if not name: name = 'Unknown'
		if not iconimage: iconimage = kodi.addonicon

		kodi.idle()

		liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
		xbmc.Player().play(url, liz, False)
	except:
		kodi.idle()
		kodi.notify(msg='Error playing %s' % name)