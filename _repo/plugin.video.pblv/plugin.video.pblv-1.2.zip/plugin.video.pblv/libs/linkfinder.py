import re
import kodi
import client
import player
import dom_parser2
import log_utils
import utils
import urlresolver

def find(url, name=None, iconimage=None):

	kodi.busy()

	try: url,site = url.split('|SPLIT|')
	except: 
		site = 'Unknown'
		log_utils.log('Error getting site information from :: %s' % (url), log_utils.LOGERROR)

	try:
		if 'mamcin.com' in url:
			c = client.request(url)
			r = dom_parser2.parse_dom(c, 'iframe', req=['src'])
			r = [i.attrs['src'] for i in r if urlresolver.HostedMediaFile(i.attrs['src']).valid_url()]
			url = r[0]

	except:
		kodi.idle()
		kodi.notify(msg='Error getting link for (Link Finer) %s' % name)
		kodi.idle()
		quit()

	url += '|SPLIT|%s' % site
	kodi.idle()

	player.resolve_url(url, name, iconimage)