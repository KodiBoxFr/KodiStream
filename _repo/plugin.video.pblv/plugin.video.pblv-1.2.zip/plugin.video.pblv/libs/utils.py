# -*- coding: utf-8 -*-

import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import os, sys, urllib, urllib2
import client
import kodi
import log_utils
import api

from addon.common.addon import Addon


addon_id = 'plugin.video.pblv'
selfAddon = xbmcaddon.Addon(id=addon_id)

addon = Addon(addon_id, sys.argv)

ADDON = xbmcaddon.Addon()

ADDON_PATH = ADDON.getAddonInfo('path')

AddonTitle = ADDON.getAddonInfo('name')

icon = ADDON.getAddonInfo('icon')
fanart = ADDON.getAddonInfo('fanart')
art = ADDON_PATH + '/resources/art/' 

dialog = xbmcgui.Dialog()

def get_params():
	args = sys.argv[2]

	commands = {}

	if args:
		split_commands = args[args.find('?') +1:].split('&')

		for command in split_commands:
			if len(command) > 0:
				if '=' in command:
					split_command = command.split('=')
					key = split_command[0]
					value = urllib.unquote_plus(split_command[1])
					commands[key] = value
				else:
					commands[command] = ''

	return commands

def checkUrl(url):
    try:
        urllib2.urlopen(url)
        return True
    except urllib2.HTTPError, e:
        return False

def buildDir(items, content='dirs', cm=None, search=False, stopend=False, isVideo = False, isDownloadable = False, cache=True, pictures=False):
    if items == None or len(items) == 0:
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        sys.exit()

    sysaddon = sys.argv[0]
    syshandle = int(sys.argv[1])

    for i in items:

        name = i['name']
        name = kodi.sortX(name)
        item = xbmcgui.ListItem(label=name)

        if i['description']: description = i['description']
        else: description = ''

        description = client.replaceHTMLCodes(description)
        description = kodi.sortX(description)

        item.setInfo('video', {'title': name, 'plot': description} )

        if i['url']: url = i['url']
        else: url = 'none'

        if i['icon'] == None: thumb=kodi.addonicon
        else: thumb = i['icon']
        if i['fanart'] == None: fanart=kodi.addonicon
        else: fanart = i['fanart']
        if ( not thumb == 'local' ) and ( not fanart == 'local' ):
            item.setArt({'icon': thumb, 'thumb': thumb, 'fanart': fanart})
        else:
            item.setArt({'icon': url, 'thumb': url, 'fanart': fanart})   

        if i['folder']: _folder = True
        else: _folder = False

        u= '%s?url=%s&mode=%s&name=%s&iconimage=%s&fanart=%s' \
        % (sysaddon,urllib.quote_plus(url),str(i['mode']),urllib.quote_plus(name),urllib.quote_plus(thumb),urllib.quote_plus(fanart))

        if isVideo:
            video_streaminfo = {'codec': 'h264', 'aspect': 1.78}
            item.addStreamInfo('video', video_streaminfo)

            audio_streaminfo = {'codec': 'aac', 'channels': 2}
            item.addStreamInfo('audio', audio_streaminfo)

            TheTVDB = checkUrl('https://www.thetvdb.com/')

            if TheTVDB == True:

                serie_id = int(97371)
                episode_id = int(name.replace('Episode ', ''))

                saison = api.Saison(episode_id)
                episode = api.Episode(saison, episode_id)

                thetvdb = api.TheTVDB()

                meta = {}

                infos_serie = thetvdb.getSerie(serie_id)

                infos_episode = thetvdb.getEpisode(serie_id, saison, episode)

                meta.update(infos_serie)
                meta.update(infos_episode)

                item.setInfo( type="Video", infoLabels= meta )

                item.setProperty('fanart_image', fanart)

        xbmcplugin.addDirectoryItem(handle=syshandle, url=u, listitem=item, isFolder=_folder)

def closeItemList():
	xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True)

def setView(content, viewType):
    ''' Why recode whats allready written and works well,
    Thanks go to Eldrado for it '''
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.get_setting('auto-view') == 'true':

        print addon.get_setting(viewType)
        if addon.get_setting(viewType) == 'Info':
            VT = '504'
        elif addon.get_setting(viewType) == 'Info2':
            VT = '503'
        elif addon.get_setting(viewType) == 'Info3':
            VT = '515'
        elif addon.get_setting(viewType) == 'Fanart':
            VT = '508'
        elif addon.get_setting(viewType) == 'Poster Wrap':
            VT = '501'
        elif addon.get_setting(viewType) == 'Big List':
            VT = '51'
        elif addon.get_setting(viewType) == 'Low List':
            VT = '724'
        elif addon.get_setting(viewType) == 'List':
            VT = '50'
        elif addon.get_setting(viewType) == 'Default Menu View':
            VT = addon.get_setting('default-view1')
        elif addon.get_setting(viewType) == 'Default TV Shows View':
            VT = addon.get_setting('default-view2')
        elif addon.get_setting(viewType) == 'Default Episodes View':
            VT = addon.get_setting('default-view3')
        elif addon.get_setting(viewType) == 'Default Movies View':
            VT = addon.get_setting('default-view4')
        elif addon.get_setting(viewType) == 'Default Docs View':
            VT = addon.get_setting('default-view5')
        elif addon.get_setting(viewType) == 'Default Cartoons View':
            VT = addon.get_setting('default-view6')
        elif addon.get_setting(viewType) == 'Default Anime View':
            VT = addon.get_setting('default-view7')

        print viewType
        print VT
        
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )

    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )


